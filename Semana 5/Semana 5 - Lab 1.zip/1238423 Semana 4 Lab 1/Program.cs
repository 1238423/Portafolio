﻿// See https://aka.ms/new-console-template for more information
int manoJ1; // variable

Console.WriteLine("Por favor ingrese la mano del J1");
manoJ1 = int.Parse(Console.ReadLine()); // se pido el dato a la consola
Console.WriteLine("La mano del jugador 1 es " + manoJ1);
